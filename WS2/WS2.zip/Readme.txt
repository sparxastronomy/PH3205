Instructions for Running:
######################################################################


1. The notebook('WS2_notebook.ipynb')  contains solution to both the problem, and is commented.

Individual .py files were also created
1. For solution to problem 1 run: WS2_1.py
    The order of error is obtained as ~ O(h^4)

2. For solution to problem 1 run: WS2_2.py