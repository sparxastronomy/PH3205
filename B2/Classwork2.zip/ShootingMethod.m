% This matlab script will demonstrate the implementation of 
% shooting method in Matlab


% Defininging Constants for the given problem
E = 200*10^9;      %Pa
I = 30000*(1/100)^4;     %m4
w = 15000;             %N/m
L = 3;               %m

%% Defining system of first order differential equaitons for given problem
yp = @(x,y) [y(2); 1/(E*I)*((w*L*x/2)-(w*x^2)/2)];

% Boundary Conditions
y0 = 0; yL = 0;

% Inital Guesses
ICguesses = [1 -2];

%% getting solution
[x1, y1] = ode45(yp, [0 L], [y0 ICguesses(1)]);
[x2, y2] = ode45(yp, [0 L], [y0 ICguesses(2)]);

% storring only the position
shot1 = y1(end,1);
shot2 = y2(end,1);
S = [shot1, shot2];

% interpolating the two solution to get a new solution
newSOL = interp1(S, ICguesses, yL, 'linear', 'extrap');

[x3, y3] = ode45(yp, [0 L], [y0 newSOL]);

%Analytical solutions
xx = linspace(0,L);
y_analytical = w/(24*E*I)*(2*L*xx.^3-xx.^4-L^3*xx);

%% Plotting the solution
figure(1)
plot(xx, y_analytical, 'b--', LineWidth=2, ...
    DisplayName='Analytical Solution')
hold on
plot(x3, y3(:,1),'ro',MarkerSize=8,MarkerFaceColor='red', ...
    DisplayName='Numerical Solution')
legend(Location="best", FontSize=14)
xlabel('$x~(m)$','Interpreter','latex', FontSize=18)
ylabel('$y~(m)$','Interpreter','latex', FontSize=18)
title("Deflection of Beam", FontSize=22)





