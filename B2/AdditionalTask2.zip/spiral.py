# improrting libraries
import numpy as np
from matplotlib.animation import FuncAnimation
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

t = np.linspace(0, 100, 1000)
# Speed along z-axis:
v_z = 10  # m/s
v_r = 30  # m/s

amp = v_r*t

w = 0.5  # rad/s
x = amp*np.cos(w*t)
y = amp*np.sin(w*t)
z = v_z*t

# creating figure
fig = plt.figure(figsize=(10, 10), dpi=100)
ax = fig.add_subplot(111, projection="3d")

# datapoints to plot in each iteration
skip = 10

# Defining init funciton


def init_func():
    ax.clear()
    ax.set_title("Animation of Helix with increasing amplitude")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_zlabel("z")

    # setting limits of x in the plot
    ax.set_xlim((np.min(x)-1, np.max(x)+1))
    # setting limits of y in the plot
    ax.set_ylim((np.min(y)-1, np.max(y)+1))
    # setting limits of z in the plot
    ax.set_zlim((np.min(z)-1, np.max(z)+1))
    plt.grid("on")


# Defining Update function
def update_plot(val):
    ax.plot(x[val:val+skip], y[val:val+skip],
            z[val:val+skip], color="orange")


# animation function
anim = FuncAnimation(fig, update_plot, frames=np.arange(
    0, len(x), 5), init_func=init_func, interval=len(x)/60)

plt.show()

# saving the animation
#anim.save('spiral.gif', fps=60, dpi=100)
